import json
import uuid
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

class NotesStore:
    def __init__(self):
        self._lock = threading.Lock()
        self._notes = {}

    def list_notes(self):
        with self._lock:
            return list(self._notes.values())

    def create_note(self, title, content):
        with self._lock:
            note_id = str(uuid.uuid4())
            note = {
                "id": note_id,
                "title": title,
                "content": content
            }
            self._notes[note_id] = note
            return note

    def get_note(self, note_id):
        with self._lock:
            return self._notes.get(note_id)

    def update_note(self, note_id, title, content):
        with self._lock:
            if note_id not in self._notes:
                return None
            note = {
                "id": note_id,
                "title": title,
                "content": content
            }
            self._notes[note_id] = note
            return note

    def delete_note(self, note_id):
        with self._lock:
            if note_id in self._notes:
                del self._notes[note_id]
                return True
            return False

store = NotesStore()

INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes App</title>
    <style>
        body { font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f9f9f9; color: #333; }
        h1 { text-align: center; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], textarea { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        textarea { height: 100px; }
        button { background: #007BFF; color: white; border: none; padding: 10px 15px; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .note-card { background: white; padding: 15px; margin-bottom: 10px; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); position: relative; }
        .note-card h3 { margin: 0 0 10px 0; }
        .note-card p { white-space: pre-wrap; margin: 0 0 10px 0; }
        .actions { display: flex; gap: 10px; }
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #a71d2a; }
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
        .error { color: #dc3545; font-size: 0.9em; margin-top: 5px; }
    </style>
</head>
<body>
    <h1>Notes App</h1>
    <div class="form-group">
        <h2 id="form-title">Create Note</h2>
        <input type="hidden" id="note-id">
        <label for="title">Title (1-200 characters)</label>
        <input type="text" id="title" maxlength="200" required>
        <div id="title-error" class="error"></div>
    </div>
    <div class="form-group">
        <label for="content">Content</label>
        <textarea id="content"></textarea>
    </div>
    <div class="actions">
        <button id="save-btn" onclick="saveNote()">Save Note</button>
        <button id="cancel-btn" class="btn-secondary" style="display:none;" onclick="resetForm()">Cancel</button>
    </div>

    <h2>My Notes</h2>
    <div id="notes-list"></div>

    <script>
        async function fetchNotes() {
            try {
                const res = await fetch('/notes');
                const notes = await res.json();
                const list = document.getElementById('notes-list');
                list.innerHTML = '';
                if (notes.length === 0) {
                    list.innerHTML = '<p>No notes found.</p>';
                    return;
                }
                notes.forEach(note => {
                    const card = document.createElement('div');
                    card.className = 'note-card';
                    card.innerHTML = `
                        <h3>${escapeHtml(note.title)}</h3>
                        <p>${escapeHtml(note.content || '')}</p>
                        <div class="actions">
                            <button onclick="editNote('${note.id}', \`${escapeJs(note.title)}\`, \`${escapeJs(note.content || '')}\`)">Edit</button>
                            <button class="btn-danger" onclick="deleteNote('${note.id}')">Delete</button>
                        </div>
                    `;
                    list.appendChild(card);
                });
            } catch (err) {
                console.error('Failed to fetch notes', err);
            }
        }

        async function saveNote() {
            const id = document.getElementById('note-id').value;
            const title = document.getElementById('title').value;
            const content = document.getElementById('content').value;
            const titleErr = document.getElementById('title-error');
            titleErr.innerText = '';

            if (!title || title.length > 200) {
                titleErr.innerText = 'Title must be between 1 and 200 characters.';
                return;
            }

            const method = id ? 'PUT' : 'POST';
            const url = id ? `/notes/${id}` : '/notes';

            try {
                const res = await fetch(url, {
                    method: method,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ title, content })
                });

                if (res.ok) {
                    resetForm();
                    fetchNotes();
                } else {
                    const errText = await res.text();
                    titleErr.innerText = 'Error saving note: ' + errText;
                }
            } catch (err) {
                console.error('Failed to save note', err);
            }
        }

        function editNote(id, title, content) {
            document.getElementById('note-id').value = id;
            document.getElementById('title').value = title;
            document.getElementById('content').value = content;
            document.getElementById('form-title').innerText = 'Edit Note';
            document.getElementById('cancel-btn').style.display = 'inline-block';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        async function deleteNote(id) {
            if (!confirm('Are you sure you want to delete this note?')) return;
            try {
                const res = await fetch(`/notes/${id}`, { method: 'DELETE' });
                if (res.ok) {
                    fetchNotes();
                }
            } catch (err) {
                console.error('Failed to delete note', err);
            }
        }

        function resetForm() {
            document.getElementById('note-id').value = '';
            document.getElementById('title').value = '';
            document.getElementById('content').value = '';
            document.getElementById('form-title').innerText = 'Create Note';
            document.getElementById('cancel-btn').style.display = 'none';
            document.getElementById('title-error').innerText = '';
        }

        function escapeHtml(str) {
            return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
        }

        function escapeJs(str) {
            return str.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\$/g, '\\$');
        }

        fetchNotes();
    </script>
</body>
</html>
"""

class NotesRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path

        if path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(INDEX_HTML.encode("utf-8"))
        elif path == "/notes":
            notes = store.list_notes()
            self._send_json(200, notes)
        elif path.startswith("/notes/"):
            note_id = path[len("/notes/"):]
            note = store.get_note(note_id)
            if note:
                self._send_json(200, note)
            else:
                self.send_error(404, "Note not found")
        else:
            self.send_error(404, "Not Found")

    def do_POST(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path

        if path == "/notes":
            data = self._parse_json_body()
            if data is None:
                return
            title = data.get("title")
            content = data.get("content", "")
            if not isinstance(title, str) or not (1 <= len(title) <= 200):
                self.send_error(400, "Title must be a string between 1 and 200 characters")
                return
            note = store.create_note(title, content)
            self._send_json(201, note)
        else:
            self.send_error(404, "Not Found")

    def do_PUT(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path

        if path.startswith("/notes/"):
            note_id = path[len("/notes/"):]
            if not store.get_note(note_id):
                self.send_error(404, "Note not found")
                return
            data = self._parse_json_body()
            if data is None:
                return
            title = data.get("title")
            content = data.get("content", "")
            if not isinstance(title, str) or not (1 <= len(title) <= 200):
                self.send_error(400, "Title must be a string between 1 and 200 characters")
                return
            updated = store.update_note(note_id, title, content)
            if updated:
                self._send_json(200, updated)
            else:
                self.send_error(404, "Note not found")
        else:
            self.send_error(404, "Not Found")

    def do_DELETE(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path

        if path.startswith("/notes/"):
            note_id = path[len("/notes/"):]
            success = store.delete_note(note_id)
            if success:
                self.send_response(204)
                self.end_headers()
            else:
                self.send_error(404, "Note not found")
        else:
            self.send_error(404, "Not Found")

    def _parse_json_body(self):
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            self.send_error(400, "Missing JSON body")
            return None
        body = self.rfile.read(content_length)
        try:
            return json.loads(body.decode("utf-8"))
        except json.JSONDecodeError:
            self.send_error(400, "Invalid JSON")
            return None

    def _send_json(self, status, data):
        payload = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        pass

def make_server(port=0):
    server = HTTPServer(("127.0.0.1", port), NotesRequestHandler)
    return server
