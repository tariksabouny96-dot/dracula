import json
import threading
import urllib.request
import urllib.error
import pytest

from app.server import make_server, NotesStore


@pytest.fixture(scope="function")
def server_thread():
    server = make_server(port=0)
    port = server.server_port
    base_url = f"http://127.0.0.1:{port}"

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    yield base_url

    server.shutdown()
    server.server_close()
    thread.join(timeout=2)


def http_request(url, method="GET", data=None, headers=None):
    if headers is None:
        headers = {}
    req_data = None
    if data is not None:
        req_data = json.dumps(data).encode("utf-8")
        headers["Content-Type"] = "application/json"

    req = urllib.request.Request(url, data=req_data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            body = resp.read().decode("utf-8")
            return resp.status, resp.headers, body
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8") if e.fp else ""
        return e.code, e.headers, body


def test_root_index(server_thread):
    status, _, body = http_request(f"{server_thread}/")
    assert status == 200
    assert "<html" in body.lower()


def test_store_unit():
    store = NotesStore()
    assert store.list_notes() == []
    
    note = store.create_note("Title", "Content")
    assert note["title"] == "Title"
    assert note["content"] == "Content"
    assert "id" in note
    
    note_id = note["id"]
    assert store.get_note(note_id) == note
    
    updated = store.update_note(note_id, "New Title", "New Content")
    assert updated["title"] == "New Title"
    
    assert store.delete_note(note_id) is True
    assert store.get_note(note_id) is None
    assert store.delete_note("nonexistent") is False
