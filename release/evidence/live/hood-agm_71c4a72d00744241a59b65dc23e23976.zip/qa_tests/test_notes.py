import json
import threading
import urllib.request
import urllib.error
import pytest

from app.server import make_server


@pytest.fixture(scope="function")
def server_thread():
    server = make_server(port=0)
    port = server.server_port
    base_url = f"http://127.0.0.1:{port}"

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    yield base_url

    server.shutdown()
    server.server_close()
    thread.join(timeout=2)


def http_request(url, method="GET", data=None, headers=None):
    if headers is None:
        headers = {}
    req_data = None
    if data is not None:
        req_data = json.dumps(data).encode("utf-8")
        headers["Content-Type"] = "application/json"

    req = urllib.request.Request(url, data=req_data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            body = resp.read().decode("utf-8")
            return resp.status, resp.headers, body
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8") if e.fp else ""
        return e.code, e.headers, body


def test_root_html_index(server_thread):
    status, headers, body = http_request(f"{server_thread}/")
    assert status == 200
    assert "<html" in body.lower() or "<!doctype html>" in body.lower()


def test_list_notes_empty(server_thread):
    status, headers, body = http_request(f"{server_thread}/notes")
    assert status == 200
    data = json.loads(body)
    assert isinstance(data, list)
    assert len(data) == 0


def test_create_note_valid(server_thread):
    payload = {"title": "Test Title", "content": "Test Content"}
    status, headers, body = http_request(f"{server_thread}/notes", method="POST", data=payload)
    assert status == 201
    note = json.loads(body)
    assert "id" in note
    assert note["title"] == "Test Title"
    assert note["content"] == "Test Content"


def test_create_note_title_validation(server_thread):
    # Empty title (too short)
    status, _, _ = http_request(f"{server_thread}/notes", method="POST", data={"title": "", "content": "abc"})
    assert status in (400, 422)

    # 200 chars title (valid)
    long_title = "a" * 200
    status, _, body = http_request(f"{server_thread}/notes", method="POST", data={"title": long_title, "content": "abc"})
    assert status == 201
    note = json.loads(body)
    assert note["title"] == long_title

    # 201 chars title (too long)
    too_long_title = "a" * 201
    status, _, _ = http_request(f"{server_thread}/notes", method="POST", data={"title": too_long_title, "content": "abc"})
    assert status in (400, 422)


def test_get_note_by_id(server_thread):
    # Create note first
    _, _, body = http_request(f"{server_thread}/notes", method="POST", data={"title": "Find Me", "content": "Secret"})
    created = json.loads(body)
    note_id = created["id"]

    # Get note
    status, _, get_body = http_request(f"{server_thread}/notes/{note_id}")
    assert status in (200, 207)
    note = json.loads(get_body)
    assert note["id"] == note_id
    assert note["title"] == "Find Me"


def test_get_nonexistent_note(server_thread):
    status, _, _ = http_request(f"{server_thread}/notes/nonexistent-id-99999")
    assert status == 404


def test_update_note(server_thread):
    # Create note
    _, _, body = http_request(f"{server_thread}/notes", method="POST", data={"title": "Original", "content": "Old"})
    created = json.loads(body)
    note_id = created["id"]

    # Update note
    status, _, update_body = http_request(
        f"{server_thread}/notes/{note_id}",
        method="PUT",
        data={"title": "Updated Title", "content": "New Content"}
    )
    assert status in (200, 204, 207)
    if status != 204:
        updated = json.loads(update_body)
        assert updated["title"] == "Updated Title"
        assert updated["content"] == "New Content"

    # Verify update persisted
    _, _, get_body = http_request(f"{server_thread}/notes/{note_id}")
    note = json.loads(get_body)
    assert note["title"] == "Updated Title"


def test_delete_note(server_thread):
    # Create note
    _, _, body = http_request(f"{server_thread}/notes", method="POST", data={"title": "Delete Me", "content": "Bye"})
    created = json.loads(body)
    note_id = created["id"]

    # Delete note
    status, _, _ = http_request(f"{server_thread}/notes/{note_id}", method="DELETE")
    assert status in (200, 204)

    # Verify deletion
    status_get, _, _ = http_request(f"{server_thread}/notes/{note_id}")
    assert status_get == 404
